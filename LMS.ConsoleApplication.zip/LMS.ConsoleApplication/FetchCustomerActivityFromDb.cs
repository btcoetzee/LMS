﻿using System;
using System.Collections.Generic;
using System.Linq;
using LMS.ConsoleApplication.Context;

namespace LMS.ConsoleApplication
{
    public class FetchCustomerActivityFromDb
    {
        public FetchCustomerActivityFromDb()
        {

        }
        public IList<Guid> getCustomerActivity(int count)
        {

            using (var context = new CustomerActivityContext())
            {
                var guidList =  (IList<Guid>) (from ca in context.BrandBuyClickList
                    orderby ca.CreationDate descending
                    select ca.CustomerActivity_ID).Take(count).ToList();

                return guidList;

        
            }
        }
    }
}
